<?php
session_start();

// Check if OTP and creation time are available in session
// If not, user accessed this page directly or session expired
if (!isset($_SESSION['otp']) || !isset($_SESSION['otp_created_at'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enter OTP</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <style>
        .btn-green {
            background-color: #34AF6D;
            border-color: #34AF6D;
            color: white;
        }
        .btn-green:hover {
            background-color: #2D945B;
            border-color: #2D945B;
        }
        .btn-green:disabled {
            background-color: #c8e6d6;
            border-color: #c8e6d6;
            color: #666;
        }
    </style>
</head>
<body class="d-flex justify-content-center align-items-center vh-100">

    <!-- OTP Form -->
    <form method="post" action="verify_otp.php" class="border p-4 rounded bg-white">
        <h4>Enter OTP</h4>

        <!-- Display user email from session -->
        <p class="text-muted">Sent to your email: <?php echo $_SESSION['email']; ?></p>
        <p class="text-danger"><small>Code will expire in 1 minute.</small></p>
        <p id="countdown" class="text-center text-muted mt-2"></p>

        <!-- OTP input -->
        <input type="text" name="otp" class="form-control mb-3" placeholder="Enter 6-digit OTP" required>

        <!-- Verify and Resend buttons -->
        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-green">Verify OTP</button>

            <!-- Resend button initially disabled until OTP expires -->
            <a id="resendBtn" href="resend_otp.php" class="btn btn-green mt-2 disabled-link" onclick="return false;">Resend OTP</a>
        </div>
    </form>

    <script>
        // Get OTP timestamp from PHP session
        const otpCreatedAt = <?php echo $_SESSION['otp_created_at']; ?>;
        const otpExpirySeconds = 60; // 1 minute

        const resendBtn = document.getElementById('resendBtn');

        function updateCountdown() {
            const now = Math.floor(Date.now() / 1000); // Current time in seconds
            const remaining = otpExpirySeconds - (now - otpCreatedAt); // Remaining time

            const countdownEl = document.getElementById("countdown");

            if (remaining > 0) {
                // Show time left and disable resend button
                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;
                countdownEl.textContent = `OTP expires in ${minutes}:${seconds.toString().padStart(2, '0')}`;
                
                resendBtn.classList.add('disabled');
                resendBtn.classList.add('btn-disabled');
                resendBtn.setAttribute('onclick', 'return false;');
            } else {
                // When OTP expires, allow resend
                countdownEl.textContent = "OTP has expired. You can now resend.";
                resendBtn.classList.remove('disabled');
                resendBtn.removeAttribute('onclick');
                resendBtn.href = "resend_otp.php";
            }
        }

        // Initial call and update every second
        updateCountdown();
        const interval = setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
