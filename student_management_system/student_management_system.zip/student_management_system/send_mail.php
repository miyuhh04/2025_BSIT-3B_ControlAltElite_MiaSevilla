<?php
// Load PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include the PHPMailer library files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Function to send OTP via email
function sendOTPEmail($toEmail, $toName, $otp) {
    $mail = new PHPMailer(true); // Create PHPMailer instance with exception handling

    try {
        // SMTP server configuration
        $mail->isSMTP();                                      // Use SMTP protocol
        $mail->Host = 'smtp.gmail.com';                       // Gmail SMTP server
        $mail->SMTPAuth = true;                               // Enable authentication
        $mail->Username = 'miya66524@gmail.com';              // Sender's Gmail address
        $mail->Password = 'ynhs yzwb lgzt fvea';              // Gmail App Password (NOT your actual Gmail password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;   // Enable TLS encryption
        $mail->Port = 587;                                    // TLS port

        $mail->setFrom('miya66524@gmail.com', 'Student System');  // Sender's email and name
        $mail->addAddress($toEmail, $toName);                     // Recipient's email and name

        // Email content
        $mail->isHTML(true);  // Email format is HTML
        $mail->Subject = 'Your OTP Code';  // Email subject
        $mail->Body    = "
            <h2>Hello, $toName</h2>
            <p>Your OTP code is: <strong>$otp</strong></p>
            <p>This code will expire in 1 minute.</p>
        ";

        $mail->send();  // Attempt to send the email
        return true;

    } catch (Exception $e) {
        // Log error to server logs if email fails
        error_log("Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>
