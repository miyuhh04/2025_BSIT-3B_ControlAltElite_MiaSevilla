<?php
session_start();
include_once 'database.php'; // make sure this is included for DB access

if (!isset($_SESSION['otp']) || !isset($_SESSION['otp_created_at'])) {
    echo "<script>
        alert('Session expired or invalid access.');
        window.location.href = 'login.php';
    </script>";
    exit();
}

// Check OTP expiration
if (time() - $_SESSION['otp_created_at'] > 300) {
    unset($_SESSION['otp'], $_SESSION['otp_created_at'], $_SESSION['temp_user'], $_SESSION['email']);

    echo "<script>
        alert('OTP expired. Please login again.');
        window.location.href = 'login.php';
    </script>";
    exit();
}

// Check OTP match
if ($_POST['otp'] == $_SESSION['otp']) {
    // Retrieve user access from the database
    $username = $_SESSION['temp_user'];
    $stmt = $con->prepare("SELECT access FROM student_users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        $_SESSION['UserLogin'] = $username;
        $_SESSION['Access'] = $user['access']; // this could be 'admin' or 'user'

        // Clean up
        unset($_SESSION['otp'], $_SESSION['otp_created_at'], $_SESSION['temp_user'], $_SESSION['email']);

        header("Location: index.php"); // index.php should redirect based on access
        exit();
    } else {
        echo "<script>
            alert('Failed to verify access.');
            window.location.href = 'login.php';
        </script>";
    }
} else {
    echo "<script>
        alert('Invalid OTP. Try again.');
        window.location.href = 'otp.php';
    </script>";
}
?>
