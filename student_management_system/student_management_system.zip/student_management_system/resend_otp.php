<?php
session_start(); 
require 'send_mail.php'; 

// Ensure the user has passed login and their email is available
if (!isset($_SESSION['temp_user']) || !isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login if session data is missing
    exit();
}

// Generate a new 6-digit OTP and store it with current timestamp
$otp = rand(100000, 999999);
$_SESSION['otp'] = $otp;
$_SESSION['otp_created_at'] = time(); // Reset OTP timer

// Attempt to send the new OTP via email
if (sendOTPEmail($_SESSION['email'], $_SESSION['temp_user'], $otp)) {
    // Notify user OTP was sent and redirect back to OTP input page
    echo "<script>
        alert('A new OTP has been sent to your email.');
        window.location.href = 'otp.php';
    </script>";
} else {
    // Notify user of failure to send OTP
    echo "<script>
        alert('Failed to resend OTP. Please try again.');
        window.location.href = 'otp.php';
    </script>";
}
?>
