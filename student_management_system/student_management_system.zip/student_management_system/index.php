<?php
// Start the session if it hasn't been started
session_start();

// Redirect to login page if the user is not logged in
if (!isset($_SESSION['UserLogin'])) {
    header("Location: login.php");
    exit;
}

// Database connection file
include_once 'database.php';

// Retrieve all students from the database, ordered by the most recent entry
$sql = "SELECT * FROM students_list ORDER BY id DESC";
$students = $con->query($sql) or die($con->error);
$row = $students->fetch_assoc();
?>


<html lang="en">
<head>
    <!-- Meta tags and css external stylesheets -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="font/bootstrap-icons.css">
    <link rel="icon" type="image" href="images/favicon.jpg">
    <link rel="stylesheet" href="css/design.css">
    <title>Student Management System</title>
</head>
<body>
    <div class="container">
        <!-- Navigation menu -->
        <nav>
            <ul>
                <li>
                    <a class="logo">
                        <img src="images/profile.png">
                        <span class="nav-item">
                            <?php echo ($_SESSION['Access'] == 'admin') ? 'Admin' : 'Guest'; ?>
                        </span>
                    </a>
                </li>
                <?php if ($_SESSION['Access'] == 'admin') { ?>
                    <li><a href="add-student.php"><i class="bi bi-person-fill-add"></i><span class="nav-item">Add</span></a></li>
                <?php } ?>
                <li><a href="logout.php"><i class="bi bi-box-arrow-right"></i><span class="nav-item">Logout</span></a></li>
            </ul>
        </nav>

        <!-- Main section -->
        <section class="main">
            <div class="main-top">
                <h1>Student Management System</h1>
                <form action="search-result.php" method="get">
                    <input type="text" id="search" name="search" placeholder="Type here...">
                    <button type="submit">Search</button>
                </form>
            </div>
            <!-- Table displaying students -->
            <table class="table">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php do { ?>
                        <tr>
                            <td><?php echo $row['first_name']; ?></td>
                            <td><?php echo $row['surname']; ?></td>
                            <?php if ($_SESSION['Access'] == 'admin') { ?>
                                <!-- Button for admins to view details -->
                                <td>
                                    <a href="details.php?ID=<?php echo $row['id']; ?>"><button>View</button></a>
                                </td>
                            <?php } else { ?>
                                <!-- Guests are restricted from viewing details -->
                                <td><button onclick="guestWarning()">View</button></td>
                            <?php } ?>
                        </tr>
                    <?php } while ($row = $students->fetch_assoc()); ?>
                </tbody>
            </table>
        </section>
    </div>
    
        <!-- Warn guests about restricted access -->
    <script>
    function guestWarning() {
        alert("Access denied. Only admins can view user details.");
    }
    </script>
</body>
</html>
