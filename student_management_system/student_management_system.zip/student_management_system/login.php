<?php
session_start(); // Start session to store temporary data like username, OTP, etc.

include_once 'database.php';     // Connect to the database
require 'send_mail.php';         // Include email sending function (PHPMailer)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];    
    $password = $_POST['password']; 

    // Query the database for the given username
    $stmt = $con->prepare("SELECT * FROM student_users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // If user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Check if the provided password matches
        if ($user['password'] === $password) {
            // Store temporary session data for OTP verification
            $_SESSION['temp_user'] = $user['username'];
            $_SESSION['email'] = $user['email'];

            // Generate a 6-digit OTP and store it with a timestamp
            $otp = rand(100000, 999999);
            $_SESSION['otp'] = $otp;
            $_SESSION['otp_created_at'] = time();

            // Send OTP to user's email
            if (sendOTPEmail($user['email'], $user['username'], $otp)) {
                header("Location: otp.php"); // Redirect to OTP input page
                exit();
            } else {
                // Show error if OTP sending fails
                echo "<script>alert('Failed to send OTP.'); window.location.href = 'login.php';</script>";
                exit();
            }
        }
    }

    // If no user found or password doesn't match
    echo "<script>
        alert('Invalid username or password.');
        window.location.href = 'login.php';
    </script>";
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta tags and external CSS files for styling -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="font/bootstrap-icons.css">
    <link rel="icon" type="image" href="images/favicon.jpg">
    <link rel="stylesheet" href="css/login.css">
    <title>Student Management System</title>
</head>

<body>

    <!--Login page main container -->
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="row border rounded-5 p-3 bg-white shadow box-area">

            <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box" style="background: url('images/pic1.jpg')">
            </div>

            <div class="col-md-6 right-box">
                <form action="" method="post">
                    <div class="row align-items-center">
                    
                        <div class="header-text mb-4">
                            <h2>Hello, Again</h2>
                            <p>We are happy to have you back.</p>
                        </div>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control form-control-lg bg-light fs-6" name="username" id="username" placeholder="Username">
                        </div>

                        <div class="input-group mb-1">
                            <input type="password" class="form-control form-control-lg bg-light fs-6" name="password" id="password" placeholder="Password" required>
                        </div>
                
                        <div class="input-group mb-5 d-flex justify-content-between">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="formCheck">
                                <label for="formCheck" class="form-check-label text-secondary"><small>Remember Me</small></label>
                            </div>
                        </div>
                        
                        <div class="input-group mb-3">
                            <button class="btn btn-lg btn-primary w-100 fs-6" type="submit" name="login">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>